
Setup Database and Tables

1 Q-Create a new database (named Loans) in SQL Server - 2Marks

COMPLETED

2 Q Import the 4 CSV files and generate 4 tables in the database. Ensure that the tables are named in a manner that is easy to understand, and that the data type for each column is correctly specified (Refer to above section for more info). In particular, ensure that the date format for the date columns are accurately defined (i.e., %Y-%m-%d). - 10 Marks

COMPLETED

3 Q Write a query to print all the databases available in the SQL Server. - 1Marks

SELECT name FROM sys.databases


4 Q Write a query to print the names of the tables from the Loans database. - 1Marks


USE DB_NAMED_LOANS

SELECT NAME
FROM sys.Tables

--SELECT * FROM information_schema.tables


5 Q Write a query to print 5 records in each table - 1Marks



Select * FROM BANKER_DATA LIMIT5
SELECT * FROM customer_daTA LIMIT5
SELECT * FROM home_loan_data LIMIT5
SELECT * FROM loan_records_data LIMIT5

.................................................................................

TASK 2

.................................................................................
Q. Find the maximum property value (using appropriate alias) of each property type, ordered by the maximum property
value in descending order.  (1 Marks)

SELECT  TOP 1 property_type, MAX(property_value) AS max_property_value
FROM HOME_LOAN_DATA
GROUP BY property_type
ORDER BY max_property_value DESC



Q Find the names of the top 3 cities (based on descending alphabetical order) and corresponding loan percent (in ascending order) with the 
lowest average loan percent.  (2 Marks)

SELECT TOP 3 city, AVG(loan_percent) AS avg_loan_percent
FROM HOME_loan_DATA
GROUP BY city
ORDER BY avg_loan_percent ASC

Q. Find the average age (at the point of loan transaction, in years and nearest integer) of female customers
who took a non-joint loan for townhomes.  (2 Marks)

--SELECT * FROM HOME_LOAN_DATA
--SELECT * FROM CUSTOMER_DATA
--SELECT * FROM LOAN_RECORDS_DATA

SELECT (SUM((YEAR(L.TRANSACTION_DATE)-YEAR(C.DOB)))/ COUNT ((YEAR(L.TRANSACTION_DATE)-YEAR(C.DOB))))AS AGE_AT_TX
FROM HOME_LOAN_DATA AS H
JOIN LOAN_RECORDS_DATA AS L ON H.LOAN_ID=L.LOAN_ID
JOIN CUSTOMER_DATA AS C ON C.CUSTOMER_ID=L.CUSTOMER_ID
WHERE C.GENDER='FEMALE' AND H.JOINT_LOAN= '0' AND H.PROPERTY_TYPE='TOWNHOME'

--TX-DOB
--COUNT RECORDS
--TX-DOB/COUNT RECORDS=AVG AGE

Q. Find the city name and the corresponding average property value (using appropriate alias) for cities 
where the average property value is greater than $3,000,000.  (1 Marks)

SELECT city, AVG(property_value) AS avg_property_value
FROM HOME_LOAN_DATA
WHERE property_value > 3000000
GROUP BY city
ORDER BY avg_property_value DESC;


Q. Find the average age of male bankers (years, rounded to 1 decimal place) based on the date they joined WBG  (2 Marks)


select gender,avg(datediff(YEAR,dob,date_joined )) as Avg_age
from Banker_DATA
where gender='Male'
group by gender;

Q. Find the average loan term for loans not for semi-detached and townhome property types, and are in the following 
list of cities: Sparks, Biloxi, Waco, Las Vegas, and Lansing.  (2 Marks)

select  avg(loan_term) as Avg_Loan_Term
from home_LOAN_DATA
where property_type 
not in ('Semi-Detached','Townhome') 
and city in ('Sparks','Biloxi','Waco','Las Vegas','Lansing')

Q. Find the customer ID, first name, last name, and email of customers whose email address contains the term 'amazon'.  (1 Marks)

select Customer_id,first_name,last_name,email
from Customer_DATA
where email like '%amazon%'
group by customer_id,first_name,last_name,email
order by customer_id;

Q. Find the total number of different cities for which home loans have been issued.  (1 Marks)

select count(distinct city) AS Total_Cities_With_HomeLoans
FROM Home_LOAN_DATA;

Q. Find the number of home loans issued in San Francisco.  (1 Marks)

select 'San Francisco' as City_Name,count(*) as NO_of_Home_Loans
from Home_LOAN_DATA
where city='San Francisco'

Q. Find the ID, first name, and last name of the top 2 bankers (and corresponding transaction count) involved in the 
highest number of distinct loan records.  (2 Marks)

select top 2 b.banker_id,b.first_name,b.last_name ,count(distinct (l.loan_id)) as Transaction_Count
from Banker_data as b 
JOIN
loan_Records_data as l
on b.banker_id=l.banker_id
group by b.banker_id,b.first_name,b.last_name
order by Transaction_Count DESC;



.................................................................................

TASK 3

.................................................................................

Q. Find the top 3 transaction dates (and corresponding loan amount sum) for which 
the sum of loan amount issued on that date is the highest.  (3 Marks)

SELECT TOP 3 transaction_date, SUM(PROPERTY_VALUE*0.01*LOAN_PERCENT) AS loan_amount_sum
FROM LOAN_RECORDS_DATA AS L
JOIN HOME_LOAN_DATA AS H
ON H.LOAN_ID=L.LOAN_ID
GROUP BY transaction_date
ORDER BY loan_amount_sum DESC


Q. Find the ID and full name (first name concatenated with last name) of customers who 
were served by bankers aged below 30 (as of 1 Aug 2022).  (3 Marks)


SELECT C.customer_id, CONCAT(C.first_name, ' ',C.last_name) AS full_name 
FROM customer_DATA AS C
JOIN LOAN_RECORDS_DATA AS L ON C.customer_id = L.customer_id
JOIN BANKER_DATA AS B ON B.banker_id = L.BANKER_id
WHERE DATEDIFF(YEAR, B.DOB, '2022-08-01') < 30


Q. Create a stored procedure called `recent_joiners` that returns the ID, concatenated full name, date of birth, 
and join date of bankers who joined within the recent 2 years (as of 1 Sep 2022).
Call the stored procedure `recent_joiners` you created above (5 Marks


CREATE PROCEDURE sprecent_joiners
AS
BEGIN
SELECT BANKER_id,CONCAT(first_name, ' ', last_name) AS full_name, dOB, DATE_JOINED
FROM banker_data
WHERE DATE_JOINED >= '2020-09-01'
AND DATE_JOINED<= '2022-09-01'
end

sprecent_joiners --sp is suffix important
                 --where you can find it inside programability

Call the stored procedure `recent_joiners` you created above (5 Marks)

Q. Find the number of Chinese customers with joint loans with property values less than $2.1 million, and served by female bankers. (3 Marks)

select count(c.customer_id)as count_
from customer_data as c
join loan_records_data as l on c.customer_id=l.customer_id
join banker_data as b on b.banker_id=l.banker_id
join home_loan_data as h on h.loan_id=l.loan_id
where c.nationality='china' and h.property_value=2100000 and b.gender='female' and h.joint_loan='1'

/*select *from home_loan_data
select * 
from customer_data 
where (nationality='italy')*/


Q. Find the ID, first name and last name of customers with properties of value between $1.5 and $1.9 million, along with a 
new column 'tenure' that categorizes how long the customer has been with WBG. 

The 'tenure' column is based on the following logic:
Long: Joined before 1 Jan 2015
Mid: Joined on or after 1 Jan 2015, but before 1 Jan 2019
Short: Joined on or after 1 Jan 2019
(2 Marks)

solution

SELECT c.customer_id, c.first_name,c.last_name,
CASE WHEN customer_since < '2015-01-01' THEN 'Long'
WHEN customer_since < '2019-01-01' THEN 'Mid'
ELSE 'Short' END AS tenure
FROM customer_data as c
join loan_records_data as l on c.customer_id=l.customer_id
JOIN home_loan_data as h ON h.loan_id = l.loan_id
WHERE h.property_value BETWEEN 1500000 AND 1900000;

Q. Find the number of bankers involved in loans where the loan amount is greater than the average loan amount.  (3 Marks)


SELECT COUNT(DISTINCT banker_id) AS num_bankers
FROM  loan_records_data as l
JOIN home_loan_data as h ON h.loan_id = l.loan_id
WHERE (h.property_value*0.01*h.loan_percent)> (SELECT AVG(property_value*0.01*loan_percent) FROM home_loan_data);


--This query will first calculate the average loan amount. Then, it will filter the results 
--to only include loans where the loan amount is greater than the average loan amount. Finally, 
--it will count the number of distinct banker IDs in the filtered results.

Q. Find the sum of the loan amounts ((i.e., property value x loan percent / 100) for each banker ID, excluding properties based 
in the cities of Dallas and Waco. The sum values should be rounded to nearest integer.  (3 Marks)

SELECT banker_id,round((h.property_value*0.01*h.loan_percent),0)as sum_loan_amount
FROM  loan_records_data as l
JOIN home_loan_data as h ON h.loan_id = l.loan_id
where city NOT IN ('Dallas', 'Waco')


Q. Create a view called `dallas_townhomes_gte_1m` which returns all the details of loans involving properties 
of townhome type, located in Dallas, and have loan amount of >$1 million. (3 Marks)

CREATE VIEW view_name AS
SELECT column1, column2, ...
FROM table_name
WHERE condition;

CREATE VIEW dallas_townhomes_gte_1m AS
SELECT
  h.loan_id,
  h.property_type,
  h.loan_percent,
  h.property_value,
  h.city,
  l.transaction_date
FROM
  home_loan_data as h
  JOIN loan_records_data as l ON h.loan_id = l.loan_id
WHERE
   (h.property_value*0.01*h.loan_percent) > 1000000;

  select* from dallas_townhomes_gte_1m --every field should be unique
                                       --two way to make view
									   --visit using database there is view created
									   --as is important key
									   --we use view to maintain data in limited outlook
									   --once created it can server at sever by using above command

Q. Create a stored procedure called `city_and_above_loan_amt` that takes in two parameters (city_name, loan_amt_cutoff) 
that returns the full details of customers with loans for properties in the input city and with loan amount greater 
than or equal to the input loan amount cutoff.  

Call the stored procedure `city_and_above_loan_amt` you created above, based on the city San Francisco and loan amount 

#CREATING PROCEDURE `city_and_above_loan_amt`

ALTER PROCEDURE spcity_and_above_loan_amt
@city_NAME NVARCHAR(20)=NULL,
@LOAN_AMT_CUTOFF INT=NULL

AS
BEGIN
  SELECT
   c.customer_id,
   c.FIRST_name,
   c.email,
   c.phone,
   H.loan_id,
   H.loan_PERCENT,
   H.property_VALUE,
   H.property_type,
   H.city
  FROM
    customer_DATA AS C
    JOIN LOAN_RECORDS_DATA AS L ON c.customer_id = l.customer_id
    JOIN HOME_LOAN_DATA AS H ON H.LOAN_id = L.LOAN_id                                        -------WHERE H.CITY='ATLANTA'
  WHERE
   ( H.city = @CITY_NAME OR @CITY_NAME IS NULL)

    AND 
	(h.property_value*0.01*h.loan_percent) >= 1500000
	END;
	 
	
	#Call the stored procedure `city_and_above_loan_amt` you created above, based on the city San Francisco and loan amount 

	EXECUTE spcity_and_above_loan_amt @CITY_NAME='SAN FRANCISCO',@LOAN_AMT_CUTOFF=1500000


 